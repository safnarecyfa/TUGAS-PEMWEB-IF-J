<?php
   include 'php/koneksi.php';

   $nama = $_POST['nama'];
   $email = $_POST['email'];
   $paket = isset($_POST['paket']) ? $_POST['paket'] : "undefined";
   $fasilitas = isset($_POST['fasilitas']) ? $_POST['fasilitas'] : [];
   $lokasi = $_POST['lokasi'];
   $metode_pembayaran = $_POST['metode_pembayaran'];
   $catatan = empty($_POST['catatan']) ? "-" : $_POST['catatan'];

   $hargaPaket = 0;
   $hargafasilitas = ["Modul Cetak" => 50000, "Modul PDF" => 25000, "Video" => 75000, "Grup Telegram" => 40000];
   $hfasilitas = 0;
   $hlokasi = 0;
   $hpembayaran = 0;
   $totalHarga = 0;
   $pajak = 0;

   if ($paket == "Intensif") {
      $hargaPaket = 500000;
   } else if ($paket == "Regular") {
      $hargaPaket = 750000;
   } else if ($paket == "Supercamp") {
      $hargaPaket = 1000000;
   }

   foreach ($fasilitas as $item) {
      if (isset($hargafasilitas[$item])) {
         $hfasilitas += $hargafasilitas[$item];
      }
   }

   if ($lokasi == "Jakarta Pusat") {
      $hlokasi = 100000;
   } else if ($lokasi == "Yogyakarta") {
      $hlokasi = 80000;
   } else if ($lokasi == "Aceh") {
      $hlokasi = 120000;
   } else if ($lokasi == "Surabaya") {
      $hlokasi = 150000;
   } else if ($lokasi == "Makassar") {
      $hlokasi = 115000;
   }

   if ($metode_pembayaran == "Transfer Bank") {
      $hpembayaran = 3000;
   } else if ($metode_pembayaran == "E-Wallet") {
      $hpembayaran = 2000;
   } else if ($metode_pembayaran == "Tunai") {
      $hpembayaran = 0;
   }

   $pajak1 = ($paket == "undefined") ? 0 : 0.1;

   $totalHarga = $hargaPaket + $hfasilitas + $hlokasi + $hpembayaran;
   $pajak = $totalHarga * $pajak1;
   $total = $totalHarga + $pajak;

   $fasilitas_str = implode(", ", $fasilitas); 

   //query
   $sql = "INSERT INTO pendaftar (nama, email, paket, fasilitas, lokasi, metode_pembayaran, catatan, hargaPaket, hfasilitas, hlokasi, hpembayaran, pajak, totalHarga, total ) 
            VALUES ('$nama', '$email', '$paket', '$fasilitas_str', '$lokasi', '$metode_pembayaran', '$catatan', '$hargaPaket', '$hfasilitas', '$hlokasi', '$hpembayaran', '$pajak', '$totalHarga', '$total')";

   //jalanin
   $query= mysqli_query($koneksi, $sql);

   //handling
   if ($query) {
      header('Location: ../index.php');
      exit;
   } else {
      echo "e eh... gagal ya..?? nggakpapaaa, cobaa lagiiiii ";
   }
?>