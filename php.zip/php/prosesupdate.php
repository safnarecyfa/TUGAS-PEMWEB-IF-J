<?php 
    include 'koneksi.php';

    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $paket = isset($_POST['paket']) ? $_POST['paket'] : "undefined";
    $fasilitas = isset($_POST['fasilitas']) ? $_POST['fasilitas'] : [];
    $lokasi = $_POST['lokasi'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $catatan = empty($_POST['catatan']) ? "-" : $_POST['catatan'];

    $hargaPaket = 0;
    $hargafasilitas = ["Modul Cetak" => 50000, "Modul PDF" => 25000, "Video" => 75000, "Grup Telegram" => 40000];
    $hfasilitas = 0;
    $hlokasi = 0;
    $hpembayaran = 0;
    $totalHarga = 0;
    $pajak = 0;

    if ($paket == "Intensif") {
        $hargaPaket = 500000;
    } else if ($paket == "Regular") {
        $hargaPaket = 750000;
    } else if ($paket == "Supercamp") {
        $hargaPaket = 1000000;
    }

    foreach ($fasilitas as $item) {
        if (isset($hargafasilitas[$item])) {
            $hfasilitas += $hargafasilitas[$item];
        }
    }

    if ($lokasi == "Jakarta Pusat") {
        $hlokasi = 100000;
    } else if ($lokasi == "Yogyakarta") {
        $hlokasi = 80000;
    } else if ($lokasi == "Aceh") {
        $hlokasi = 120000;
    } else if ($lokasi == "Surabaya") {
        $hlokasi = 150000;
    } else if ($lokasi == "Makassar") {
        $hlokasi = 115000;
    }

    if ($metode_pembayaran == "Transfer Bank") {
        $hpembayaran = 3000;
    } else if ($metode_pembayaran == "E-Wallet") {
        $hpembayaran = 2000;
    } else if ($metode_pembayaran == "Tunai") {
        $hpembayaran = 0;
    }

    $pajak1 = ($paket == "undefined") ? 0 : 0.1;

    $totalHarga = $hargaPaket + $hfasilitas + $hlokasi + $hpembayaran;
    $pajak = $totalHarga * $pajak1;
    $total = $totalHarga + $pajak;

    $fasilitas_str = implode(", ", $fasilitas); 
    $fasilitas_terpilih = isset($fasilitas_terpilih) ? $fasilitas_terpilih : [];

    //query
    $sql = "UPDATE pendaftar set nama = '$nama', email='$email', paket='$paket', fasilitas='$fasilitas_str', lokasi='$lokasi', metode_pembayaran='$metode_pembayaran', 
                                        catatan='$catatan', hargaPaket='$hargaPaket', hfasilitas='$hfasilitas', hlokasi='$hlokasi', hpembayaran='$hpembayaran', pajak='$pajak', totalHarga='$totalHarga', total='$total'
            WHERE id = $id";

    //jalanin
    $query= mysqli_query($koneksi, $sql);

    //handling
    if ($query) {
        header('Location: ../index.php');
        exit;
    } else {
        echo "e eh... gagal ya..?? nggakpapaaa, cobaa lagiiiii ";
    }
?>